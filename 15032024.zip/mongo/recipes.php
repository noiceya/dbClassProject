<!DOCTYPE html>
<html lang="pl">

<head>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Przepisowo</title>
</head>

<?php
    // pobieranie list do js
    require 'vendor/autoload.php';
    $client = new MongoDB\Client(
        'mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');
    $db = $client->myDatabase->recipes;
    $data = $db->find();
    // var_dump($data); -> ładnie wypisuje zawartosc zmiennej $data
    $array = iterator_to_array($data);
    // var_dump($array);
?>  

<body>
    <?php
            foreach ($array as $value)
            {
                echo '<h1><a href="recipe.php?name=' . urlencode($value['name']) . '">' . $value['name'] . '</a></h1>';

                echo "<h1>Składniki:</h1>";
                foreach($value['ingredients'] as $index => $ingredient)
                {
                    echo " " . $ingredient;
                    echo "<br>";
                }
                
                echo "<h1>Przepis: <br>" . $value['steps'] . "</h1>";

                echo '<p>Tagi: ';
                foreach ($value['tag'] as $tag) {
                    echo '<a href="tag.php?tag=' . urlencode($tag) . '">' . $tag . '</a> ';
                }
                echo '</p>';
            } 
    ?>
</body>

</html>