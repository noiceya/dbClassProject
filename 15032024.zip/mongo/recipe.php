<link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />

<?php
    require 'vendor/autoload.php';

    $client = new MongoDB\Client(
        'mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority'
    );

    $db = $client->myDatabase->recipes;
    $data = $db->find();
    $array = iterator_to_array($data);
?>

<?php
    if(isset($_GET['name'])) 
    {
        $name = $_GET['name'];
        
        $finding = $db->find(['name' => $name]);

        foreach ($finding as $value) 
        {
            echo "<h1>" . $value['name'] . "</h1>";


            echo "<h1>Składniki:</h1>";
            foreach($value['ingredients'] as $index => $ingredient)
            {
                echo " " . $ingredient;
                echo "<br>";
            }
            
            echo "<h1>Przepis: <br>" . $value['steps'] . "</h1>";

            echo '<p>Tagi: ';
            foreach ($value['tag'] as $tag) 
            {
                echo '<a href="tag.php?tag=' . urlencode($tag) . '">' . $tag . '</a> ';
            }
            echo '</p>';
        }
    } 
    else 
    {
        echo 'Błąd. Ten przepis nie istnieje.';
    }
?>