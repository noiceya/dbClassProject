<!DOCTYPE html>
<html>
<head>
    <title>Tagi</title>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
</head>
<body>

<?php
    require 'vendor/autoload.php';
    $client = new MongoDB\Client(
        'mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');
    $db = $client->myDatabase->recipes;
    $data = $db->find();
    // var_dump($data); -> ładnie wypisuje zawartosc zmiennej $data
    $array = iterator_to_array($data);
    // var_dump($array);
?>  

<?php
    $uniqueTags = array(); 

    foreach ($array as $value) 
    {
        if(isset($value['tag'])) 
        {
            foreach ($value['tag'] as $tag) 
            {
                if (!in_array($tag, $uniqueTags)) 
                {
                    $uniqueTags[] = $tag;

                    echo '<a href="tag.php?tag=' . urlencode($tag) . '">' . $tag . '</a> ';
                }
            }
        }
    } 
?>

</body>
</html>
