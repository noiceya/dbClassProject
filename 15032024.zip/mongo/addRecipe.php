<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Przepisowo</title>
</head>
<body>
    <form action="addRecipe.php" method="post">
        <input type="hidden" name="id" value="<?=uniqid()?>" />

        <label for="name">Nazwa przepisu<br></label> <input name="name"  type="text" placeholder="Wprowadź nazwę przepisu..." id="name" title="name" required/><br><br>

        <label for="ingredients">Składniki<br></label> 
        <textarea name="ingredients" placeholder="Wprowadź składniki oddzielając je przecinkami..." id="ingredients" title="ingredients" rows="4" cols="22" required></textarea><br><br>

        <label for="steps">Przepis<br></label> 
        <textarea name="steps" placeholder="Podaj przepis..." id="steps" title="steps" rows="4" cols="22" required></textarea><br><br>
        
        <label for="type">Przepis na<br></label>
        <input type="radio" id="food" name="type" value="food">
        <label for="food">Danie</label><br>
        <input type="radio" id="dessert" name="type" value="dessert">
        <label for="dessert">Deser</label><br>
        <input type="radio" id="drink" name="type" value="drink">
        <label for="drink">Napój</label><br><br>    

        <label for="tag">Tagi<br></label> 
        <textarea name="tag" placeholder="Dodaj tagi oddzielając je przecinkami..." id="tag" title="tag" rows="4" cols="22" required></textarea><br><br>
        
        <input name="submit" type="submit" value="Dodaj &#9658;" /><br><br>
    </form>

</body>
</html>

<?php
    require 'vendor/autoload.php';
    $client = new MongoDB\Client('mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');

    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        $name = $_POST['name'];
        $ingredients = explode(", ", $_POST['ingredients']);
        $steps = $_POST['steps'];
        $type = $_POST['type'];
        $tag = explode(", ", $_POST['tag']);

        $db = $client->myDatabase->recipes;

        $insertdata = $db->insertOne([
            'name' => $name,
            'ingredients' => $ingredients,
            'steps' => $steps,
            'type' => $type,
            'tag' => $tag
        ]);

        if($insertdata) 
        {
            echo '<script>alert("Dodano przepis!");</script>';
        } else 
        {
            echo '<script>alert("Wystąpił błąd. Nie dodano przepisu.");</script>';
        }
    }
?>
