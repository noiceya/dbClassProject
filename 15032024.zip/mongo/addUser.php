<!DOCTYPE html>
<html lang="pl">

<head>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Przepisowo</title>
</head>

<body>
    <form action="addUser.php" method="post">
        <input type="hidden" name="id" value="<?=uniqid()?>" />

        <label for="username">Nazwa użytkownika<br></label> <input name="username"  type="text" placeholder="Wprowadź nazwę użytkownika..." id="username" title="username" required/><br><br>

        <label for="email">Email<br></label> <input name="email"  type="email" placeholder="Wprowadź adres email..." id="email" title="email" required/><br><br>

        <label for="password">Hasło<br></label> <input name="password"  type="password" placeholder="Wprowadź hasło..." id="password" title="password" required/><br><br>

        <input name="submit" type="submit" value="Zarejestruj &#9658;" title="Sukces!" onclick="alert('Dodano użytkownika!');" />
    </form>

</body>

</html>

<?php
    // Obsługa dodawania użytkownika do bazy danych MongoDB
    require 'vendor/autoload.php';
    // Ustawienia połączenia z bazą danych MongoDB
    $client = new MongoDB\Client('mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Wybór kolekcji w bazie danych
        $db = $client->myDatabase->users;

        // Dodanie użytkownika do bazy danych
        $insertdata = $db->insertOne([
            'username' => $username,
            'email' => $email,
            'password' => $password
        ]);

        if($insertdata) {
            echo '<script>alert("Dodano użytkownika!");</script>';
        } else {
            echo '<script>alert("Wystąpił błąd. Nie dodano użytkownika.");</script>';
        }
    }
?>