<link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />

<?php
    require 'vendor/autoload.php';

    $client = new MongoDB\Client(
        'mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority'
    );

    $db = $client->myDatabase->recipes;
    $data = $db->find();
    $array = iterator_to_array($data);
?>

<?php
    if(isset($_GET['tag'])) 
    {
        $tag = $_GET['tag'];
        
        $finding = $db->find(['tag' => $tag]);

        foreach ($finding as $value) 
        {
            echo '<pre>';
            echo "<h1>" . $value['name'] . "</h1>";
            echo '</pre>';
        }
    } 
    else 
    {
        echo 'Błąd. Ten tag nie istnieje.';
    }
?>
