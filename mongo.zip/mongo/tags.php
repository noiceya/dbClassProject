<?php
    // pobieranie list do js
    require 'vendor/autoload.php';
    $client = new MongoDB\Client(
        'mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');
    $db = $client->myDatabase->recipes;
    $data = $db->find();
    // var_dump($data); -> ładnie wypisuje zawartosc zmiennej $data
    $array = iterator_to_array($data);
    // var_dump($array);
?>  

<?php
// Pobranie tagu z parametru URL
$tag = $_GET['tag'];

// Wyświetlenie artykułów z danym tagiem
foreach ($array as $value)
{
    echo '<h2>' . $value['name'] . '</h2>';
}
?>