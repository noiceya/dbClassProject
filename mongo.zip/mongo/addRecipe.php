<!DOCTYPE html>
<html lang="pl">

<head>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Przepisowo</title>
</head>

<body>
    <form action="addRecipe.php" method="post">
        <input type="hidden" name="id" value="<?=uniqid()?>" />

        <label for="name">Nazwa przepisu<br></label> <input name="name"  type="text" placeholder="Wprowadź nazwę przepisu..." id="name" title="name" required/><br><br>

        <label for="ingredients">Składniki<br></label> <textarea name="ingredients" placeholder="Wprowadź składniki oddzielając je przecinkami..." id="ingredients" title="ingredients" rows="4" cols="22" required></textarea><br><br>

        <label for="type">Przepis na<br></label>
        <input type="radio" id="breakfast" name="type" value="breakfast">
        <label for="breakfast">Śniadanie</label><br>
        <input type="radio" id="lunch" name="type" value="lunch">
        <label for="lunch">Obiad</label><br>
        <input type="radio" id="dinner" name="type" value="dinner">
        <label for="dinner">Kolację</label><br>
        <input type="radio" id="dessert" name="type" value="dessert">
        <label for="dessert">Deser</label><br>
        <input type="radio" id="drink" name="type" value="drink">
        <label for="drink">Napój</label><br><br>
        <input name="submit" type="submit" value="Dodaj &#9658;" title="Sukces!" onclick="alert('Dodano przepis!');" />
    </form>

</body>

</html>

<?php
    // Obsługa dodawania przepisu do bazy danych MongoDB
    require 'vendor/autoload.php';
    // Ustawienia połączenia z bazą danych MongoDB
    $client = new MongoDB\Client('mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $ingredients = explode(", ", $_POST['ingredients']); // Rozbijanie składników na elementy tablicy
        $type = $_POST['type'];

        // Wybór kolekcji w bazie danych
        $db = $client->myDatabase->recipes;

        // Dodanie przepisu do bazy danych
        $insertdata = $db->insertOne([
            'name' => $name,
            'ingredients' => $ingredients,
            'type' => $type
        ]);

        if($insertdata) {
            echo '<script>alert("Dodano przepis!");</script>';
        } else {
            echo '<script>alert("Wystąpił błąd. Nie dodano przepisu.");</script>';
        }
    }
?>
