<title>Przepisowo</title>
<link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />

<?php
    require 'vendor/autoload.php';

    $client = new MongoDB\Client(
        'mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority'
    );

    $db = $client->myDatabase->recipes;
    $data = $db->find();
    $array = iterator_to_array($data);
?>

<?php
    if(isset($_GET['tag'])) 
    {
        $tag = $_GET['tag'];
        
        $finding = $db->find(['tag' => $tag]);
        $recipes = iterator_to_array($finding); // Przekształcenie kursora w tablicę
        $recipeCount = count($recipes); // Obliczenie liczby przepisów w tablicy

        if ($recipeCount > 0) {
            echo '<h1>Przepisy dla tagu: ' . $tag . '</h1>';
            foreach ($recipes as $value) 
            {
                echo '<p><a href="recipe.php?name=' . urlencode($value['name']) . '">' . $value['name'] . '</a></p>';
            }
        } else {
            echo '<p>Brak przepisów dla tagu: ' . $tag . '</p>';
        }
    } 
    else 
    {
        echo 'Błąd. Ten tag nie istnieje.';
    }
?>


