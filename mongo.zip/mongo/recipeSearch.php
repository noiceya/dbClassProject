<!DOCTYPE html>
<html>
<head>
    <title>Przepisowo</title>
    <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        #searchInput {
            width: 200px;
            padding: 10px;
            font-size: 16px;
        }
        #suggestions {
            margin-top: 5px;
            padding: 0;
            list-style: none;
        }
        #suggestions li {
            padding: 10px;
            background-color: #f4f4f4;
            cursor: pointer;
        }
        #suggestions li:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <?php
        require 'vendor/autoload.php';
        $client = new MongoDB\Client('mongodb+srv://bkinga:uQ1Xj8X34opGvLUPIQhZ@project.fwckyrf.mongodb.net/?retryWrites=true&w=majority');
        $db = $client->myDatabase->recipes;
        $data = $db->find();
        
        $names = array(); 

        foreach ($data as $document) {
            if(isset($document['name'])) {
                $names[] = $document['name'];
            }
        } 
    ?>  

    <input type="text" id="searchInput">
    <ul id="suggestions"></ul>

    <script>
        const names = <?php echo json_encode($names); ?>;

        $('#searchInput').on('input', function() 
        {
            const input = $(this).val().trim().toLowerCase();
            const suggestionsList = $('#suggestions');
            suggestionsList.empty();

            if (input === '') 
            {
                return;
            }

            const filteredNames = names.filter(name => name.toLowerCase().startsWith(input));

            filteredNames.forEach(name  => 
            {
                const link = $('<a>').attr('href', 'recipe.php?name=' + encodeURIComponent(name)).text(name);
                const li = $('<li>').append(link);
                suggestionsList.append(li);
            });
        });
    </script>
</body>
</html>
